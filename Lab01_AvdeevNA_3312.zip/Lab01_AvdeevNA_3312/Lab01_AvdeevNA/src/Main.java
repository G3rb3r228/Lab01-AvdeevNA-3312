/**
 * Laboratory work No. 1
 * @author Avdeev Nikita 3312
 * @version 1.0
 *
 *
 *This is the main class in which the code is written
 */
public class Main{
        /**
         * The main method for running the program.
         *
         *
         * @param args - launch parameter
         */
    public static void main(String[] args){

        int[] numbers = {5, 12, 23, 34, 47, 56, 78, 89, 10, 22};

        //calling the sorting function
        sortArray(numbers);

        //output the result
        System.out.println("Sorted array: ");
        for (int i = 0; i < numbers.length; i ++){
            System.out.println("number[" + i + "] = " + numbers[i]);
        }
    }

    /**
     *
     * @param arr - the array to be sorted
     */
    static void sortArray(int[] arr){
        for (int i = 0; i < arr.length; i++){
            for (int j = 0; j < arr.length - i - 1; j++){
                if (arr[j] > arr[j + 1]){
                    int tmp = arr[j + 1];
                    arr[j + 1] = arr[j];
                    arr[j] = tmp;
                }
            }
        }
    }
}